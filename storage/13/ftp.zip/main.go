package main

import (
	"fmt"
	"ftp/database"
	"net/http"
	"os"
	"strconv"

	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()

	// 测试路由
	r.GET("/ping", func(c *gin.Context) {
		c.String(http.StatusOK, "pong\n")
	})

	//静态文件服务器
	r.StaticFS("/files", http.Dir("./"))
	r.StaticFS("/web", http.Dir("./web"))

	r.StaticFile("/", "./web/index.html")
	//上传文件服务
	r.POST("/upload", func(ctx *gin.Context) {
		ctx.String(http.StatusOK, fmt.Sprintf("%s\n%s", ctx.ContentType(), ctx.Request.RemoteAddr))
		file, err := ctx.FormFile("file")
		text := ctx.GetHeader("Text")
		branch := ctx.GetHeader("Branch")
		if err != nil {
			ctx.String(http.StatusInternalServerError, "error: Get file name error.\n")
		} else {
			pwd, _ := os.Getwd()
			filepath := fmt.Sprintf("%s/files/%s", pwd, file.Filename)
			ctx.SaveUploadedFile(file, filepath)

			//放入数据库
			database.WirteToDb(filepath, text, branch)
		}
	})

	//前端获取文件信息接口
	r.GET("/getFileInfo", func(ctx *gin.Context) {

		page, err := strconv.Atoi(ctx.DefaultQuery("page", "1"))
		if err != nil {
			fmt.Println("Get page error: ", err)
		}
		size, err := strconv.Atoi(ctx.DefaultQuery("size", "15"))
		if err != nil {
			fmt.Println("Get size error: ", err)
		}

		search := ctx.DefaultQuery("search", "")

		Size, total, fileinfos := database.GetFileInfoFromDB(page, size, search)

		ctx.JSON(http.StatusOK, gin.H{
			"code":  "SUCCESS", //表示请求过去数据成功
			"data":  fileinfos, //请求的数据
			"total": total,     //总数据的数量
			"size":  Size,      //搜索返回的数据数量

		})

	})

	//更新数据服务
	r.POST("/update", func(ctx *gin.Context) {
		name := ctx.PostForm("name")
		text := ctx.PostForm("text")
		// name := ctx.DefaultQuery("name", "")
		// text := ctx.DefaultQuery("text", "")
		// fmt.Println("name is ", name, "  text is ", text)
		// fmt.Println(ctx.Request)

		ok := database.UpdateText(name, text)
		if ok {
			ctx.JSON(http.StatusOK, gin.H{
				"code": "SUCCESS",
			})
		} else {
			ctx.JSON(http.StatusInternalServerError, gin.H{
				"code": "ERROR",
			})
		}
	})

	// 启动服务器
	r.Run("0.0.0.0:8080")
}
