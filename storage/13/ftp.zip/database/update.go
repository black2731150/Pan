package database

import (
	"fmt"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func UpdateText(name string, text string) bool {

	//打开数据库
	db, err := gorm.Open(sqlite.Open("fileinfo.db"), &gorm.Config{})
	if err != nil {
		fmt.Println("Faild to connect database: ", err)
	}

	//获取数据库
	DB, err := db.DB()
	if err != nil {
		fmt.Println("Flaid get DB: ", err)
	}

	rs, err := DB.Exec("update file_infos set text=? where name = ?;", text, name)
	if err != nil {
		fmt.Println("update faild : ", err)
		return false
	}

	id, err := rs.LastInsertId()
	if err != nil {
		fmt.Println("rs id error : ", id, err)
		return false
	}

	return true
}
