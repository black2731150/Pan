package database

import (
	"fmt"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

var Total int = 0

func GetFileInfoFromDB(page, size int, search string) (int, int, []FileInfo) {

	//页数规范
	if size < 1 {
		size = 10
	}
	if page < 1 {
		page = 1
	}

	//打开数据库
	db, err := gorm.Open(sqlite.Open("fileinfo.db"), &gorm.Config{})
	if err != nil {
		fmt.Println("Faild to connect database: ", err)
	}

	//获取数据库
	DB, err := db.DB()
	if err != nil {
		fmt.Println("Flaid get DB: ", err)
	}
	//获取总数据数
	db.Raw("select count() from file_infos").Scan(&Total)

	rows, err := DB.Query("select * from file_infos where (name like ? or branch like ?) order by create_time desc limit ?,?;", "%"+search+"%", "%"+search+"%", (page-1)*size, size)
	if err != nil {
		fmt.Println("Faild to Get rows: ", err)
		panic("")
	}
	defer rows.Close()

	var Size int = 0
	var fileinfos []FileInfo
	for rows.Next() {
		fileinfo := FileInfo{}
		err := rows.Scan(&fileinfo.Name, &fileinfo.Size, &fileinfo.CreateTime, &fileinfo.DownLandURL, &fileinfo.Md5, &fileinfo.Branch, &fileinfo.Text)
		if err != nil {
			fmt.Println("Faild to Get fileinfo: ", err)
			panic("")
		}
		fileinfos = append(fileinfos, fileinfo)
		Size++
	}

	return Size, Total, fileinfos

}
