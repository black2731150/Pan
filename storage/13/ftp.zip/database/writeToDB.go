package database

import (
	"fmt"
	"ftp/common"
	"os"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

var ID int = 0

func WirteToDb(filepath string, text string, branch string) {

	file, err := os.Open(filepath)
	if err != nil {
		fmt.Println("Faild to Open file: ", err)
	}
	defer file.Close()

	filestat, err := file.Stat()
	if err != nil {
		fmt.Println("Faild to Get fileInfo: ", err)
	}

	db, err := gorm.Open(sqlite.Open("fileinfo.db"), &gorm.Config{})
	if err != nil {
		fmt.Println("Faild to connect database: ", err)
	}

	db.AutoMigrate(&FileInfo{})

	db.Create(&FileInfo{
		// ID:          ID,
		Name:        filestat.Name(),
		Size:        filestat.Size(),
		CreateTime:  filestat.ModTime().Format("2006-01-02 15:04:05"),
		DownLandURL: "/files/" + filestat.Name(),
		Md5:         common.HashMD5(filepath),
		Branch:      branch,
		Text:        text,
	})
	//fmt.Printf("Wirte fileInfo ti DB:\n Name=%s\n,Size=%d\n,CreateTime=%s\n,DownLandURL=%s,md5=%s\n", filestat.Name(), filestat.Size(), filestat.ModTime(), filepath, common.HashMD5(filepath))

}
